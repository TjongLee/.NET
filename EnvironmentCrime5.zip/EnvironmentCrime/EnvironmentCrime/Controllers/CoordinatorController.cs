﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EnvironmentCrime.Models;
using EnvironmentCrime.Infrastructure;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;

namespace EnvironmentCrime.Controllers
{
    [Authorize(Roles = "Coordinator")]
    public class CoordinatorController : Controller
    {
        private ICrimeRepository repository;

        public CoordinatorController(ICrimeRepository repo)
        {
            repository = repo;
        }

        public IActionResult Coordinator()
        {
            return View(repository);
        }

        public IActionResult CrimeCoordinator(int id)
        {
            TempData["ID"] = id;
            ViewBag.ID = id;
            IQueryable<Department> holder = repository.Departments;
            holder = holder.Skip(1);
            ViewBag.ListOfDepartments = holder;
            Department department = new Department();
            return View(department);
        }

        public IActionResult ReportCrime()
        {
            var myErrand = HttpContext.Session.GetJson<Errand>("NewErrand");
            if (myErrand == null)
            {
                return View();
            }
            else
            {
                ViewBag.id = myErrand.ErrandId;
                return View(myErrand);
            }
        }

        public IActionResult Thanks()
        {
            var myErrand = HttpContext.Session.GetJson<Errand>("NewErrand");
            repository.SaveErrand(myErrand);
            ViewBag.Ref = myErrand.RefNumber;

            HttpContext.Session.Remove("NewErrand");
            return View();
        }

        public IActionResult Validate(Errand errand)
        {
            HttpContext.Session.SetJson("NewErrand", errand);

            return View(errand);
        }

        public IActionResult AssignDepartment(string department)
        {
            int myID = int.Parse(TempData["ID"].ToString());
            if (department != "Välj")
            repository.UpdateErrandDepartment(department, myID);
       
            return View("Coordinator", repository);
        }

    }
}
