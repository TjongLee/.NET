﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EnvironmentCrime.Models;
using EnvironmentCrime.Infrastructure;
using Microsoft.AspNetCore.Http;
using System.IO;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Authorization;

namespace EnvironmentCrime.Controllers
{
    [Authorize(Roles = "Investigator")]
    public class InvestigatorController : Controller
    {
        private ICrimeRepository repository;
        private IWebHostEnvironment environment;
        private IHttpContextAccessor contextAcc;

        public InvestigatorController(ICrimeRepository repo, IWebHostEnvironment env, IHttpContextAccessor cont)
        {
            repository = repo;
            environment = env;
            contextAcc = cont;
        }
        public IActionResult Investigator()
        {
            var userName = contextAcc.HttpContext.User.Identity.Name;
            ViewBag.userName = userName;
            return View(repository);
        }

        public IActionResult CrimeInvestigator(int id)
        {
            HttpContext.Session.SetJson("OldErrandId", id);
            TempData["ID"] = id;
            ViewBag.ID = id;
            ViewBag.ListOfStatuses = repository.ErrandStatuses;
            ErrandStatus status = new ErrandStatus();
            return View(status);
        }

        public IActionResult UpdateInvestigation(string statusid, IFormFile loadSample, IFormFile loadImage, string events, string information)
        {
            int myID = int.Parse(TempData["ID"].ToString());

            repository.UpdateErrandInvestigation(statusid, loadSample.FileName, loadImage.FileName, events, information, myID);
     
            UploadFiles(loadSample, "Samples");
            UploadFiles(loadImage, "Photos");

            return View("Investigator", repository);
        }

        public async void UploadFiles (IFormFile documents, string foldername)
        {
            var tempPath = Path.GetTempFileName();

            if(documents.Length > 0)
            {
                using (var stream = new FileStream(tempPath, FileMode.Create))
                {
                    await documents.CopyToAsync(stream);
                }
            }

            string uniqueFileName = Guid.NewGuid().ToString() + "_" + documents.FileName;

            var path = Path.Combine(environment.WebRootPath, foldername, uniqueFileName);

            System.IO.File.Move(tempPath, path);
            return;
        }

    }
}
