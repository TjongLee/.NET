﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EnvironmentCrime.Models;
using EnvironmentCrime.Infrastructure;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;

namespace EnvironmentCrime.Controllers
{
    [Authorize(Roles = "Manager")]
    public class ManagerController : Controller
    {
        private ICrimeRepository repository;
        private IHttpContextAccessor contextAcc;

        public ManagerController(ICrimeRepository repo, IHttpContextAccessor cont)
        {
            repository = repo;
            contextAcc = cont;
        }

        public IActionResult Manager()
        {
            var userName = contextAcc.HttpContext.User.Identity.Name;
            ViewBag.userName = userName;

            return View(repository);
        }

        public IActionResult CrimeManager(int id)
        {
            HttpContext.Session.SetJson("OldErrandId", id);
            ViewBag.ID = id;
            var userName = contextAcc.HttpContext.User.Identity.Name;
            string dep = repository.Employees.Where(emp => emp.EmployeeId == userName).First().DepartmentId;
            ViewBag.ListOfEmployees = repository.Employees.Where(em=> em.DepartmentId == dep);
            Employee employee = new Employee();
            return View(employee);
        }

        public IActionResult AssignEmployee(string employee, bool noAction, string investigator)
        {
            int myID = int.Parse(TempData["ID"].ToString());
            if (employee != "Välj")
                repository.UpdateErrandEmployee(employee, noAction, investigator, myID);

            return View("Manager", repository);
        }
    }
}
