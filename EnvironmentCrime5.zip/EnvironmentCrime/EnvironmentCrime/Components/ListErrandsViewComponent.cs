﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using EnvironmentCrime.Models;

namespace EnvironmentCrime.Components
{
    public class ListErrandsViewComponent: ViewComponent
    {
        private ICrimeRepository repository;
        public ListErrandsViewComponent(ICrimeRepository repo)
        {
            repository = repo;
        }
        public IViewComponentResult Invoke(string name)
        {
            string role = " ";
            if (name != " ")
            { role = repository.Employees.Where(emp => emp.EmployeeId == name).FirstOrDefault().RoleTitle; }

            switch (role)
            {
                case "Manager":
                    ViewBag.controller = "Manager";
                    return View(repository.JoinManager(name));

                case "Investigator":
                    ViewBag.controller = "Investigator";
                    return View(repository.JoinInvestigator(name));
                default:
                    ViewBag.controller = "Coordinator";
                    return View(repository.JoinCoordinator());
            }
        }
    }
}
