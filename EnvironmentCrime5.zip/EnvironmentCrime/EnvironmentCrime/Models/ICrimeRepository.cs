﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EnvironmentCrime.Models
{
    public interface ICrimeRepository
    {
        IQueryable<Department> Departments { get; }
        IQueryable<ErrandStatus> ErrandStatuses { get; }
        IQueryable<Employee> Employees { get; }

        //Create and Update
        public void SaveErrand(Errand errand);

        public void UpdateErrandDepartment(string department, int id);
        public void UpdateErrandEmployee(string employee, bool noAction, string investigator, int id);
        public void UpdateErrandInvestigation(string statusid, string SampleName, string ImageName, string events, string information, int id);

        public IQueryable<MyErrand> JoinCoordinator();
        public IQueryable<MyErrand> JoinManager(string name);
        public IQueryable<MyErrand> JoinInvestigator(string name);

        //Read
        IQueryable<Errand> Errands { get; }
        Task<Errand> GetErrandDetail(int id);

        //Delete
        public Errand DeleteErrand(int errandId);
    }
}
