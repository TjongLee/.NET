﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace EnvironmentCrime.Models
{
    public class EFCrimeRepository : ICrimeRepository
    {
        private ApplicationDbContext context;

        public EFCrimeRepository(ApplicationDbContext ctx)
        {
            context = ctx;
        }

        public IQueryable<Errand> Errands => context.errands.Include(e=>e.Samples).Include(e=>e.Pictures); // get -||-
        public IQueryable<Department> Departments => context.departments;
        public IQueryable<ErrandStatus> ErrandStatuses => context.errandStatuses;
        public IQueryable<Employee> Employees => context.employees;
        public IQueryable<Sequence> Sequences => context.sequences;

        public Task<Errand> GetErrandDetail(int id)
        {
            return Task.Run(() =>
            {
                if (id == 0) return null;
                var ErrandDetail = Errands.Where(ed => ed.ErrandId == id).First();
                return ErrandDetail;
            });
        }

        public IQueryable<MyErrand> JoinCoordinator()
        {
            var errandList = from err in Errands
                             join stat in ErrandStatuses on err.StatusId equals stat.StatusId
                             join dep in Departments on err.DepartmentId equals dep.DepartmentId
                             into departmentErrand from deptE in departmentErrand.DefaultIfEmpty()
                             join em in Employees on err.EmployeeId equals em.EmployeeId
                             into employeeErrand
                             from empE in employeeErrand.DefaultIfEmpty()
                             orderby err.RefNumber descending
                             select new MyErrand
                             {
                                 DateOfObservation = err.DateOfObservation,
                                 ErrandId = err.ErrandId,
                                 RefNumber = err.RefNumber,
                                 TypeOfCrime = err.TypeOfCrime,
                                 StatusName = stat.StatusName,
                                 DepartmentName = (err.DepartmentId == null ? "ej tillsatt" : deptE.DepartmentName),
                                 EmployeeName = (err.EmployeeId == null ? "ej tillsatt" : empE.EmployeeName)
                             };

            return errandList;
        }

        public IQueryable<MyErrand> JoinManager(string name)
        {
            var department = Employees.Where(er => er.EmployeeId == name).First().DepartmentId;
            var relevantErrands = Errands.Where(er => er.DepartmentId == department);

            var errendList = from err in relevantErrands // from the errands where the department match
                             join stat in ErrandStatuses on err.StatusId equals stat.StatusId
                             join dep in Departments on err.DepartmentId equals dep.DepartmentId
                             into departmentErrand
                             from deptE in departmentErrand.DefaultIfEmpty()
                             join em in Employees on err.EmployeeId equals em.EmployeeId
                             into employeeErrand
                             from empE in employeeErrand.DefaultIfEmpty()
                             orderby err.RefNumber descending
                             select new MyErrand
                             {
                                 DateOfObservation = err.DateOfObservation,
                                 ErrandId = err.ErrandId,
                                 RefNumber = err.RefNumber,
                                 TypeOfCrime = err.TypeOfCrime,
                                 StatusName = stat.StatusName,
                                 DepartmentName = (err.DepartmentId == null ? "ej tillsatt" : deptE.DepartmentName),
                                 EmployeeName = (err.EmployeeId == null ? "ej tillsatt" : empE.EmployeeName)
                             };
            return errendList;
        }
        public IQueryable<MyErrand> JoinInvestigator(string name)
        {
            var relevantErrands = Errands.Where(er => er.EmployeeId == name);

            var errendList = from err in relevantErrands // from the errands where the name matches
                             join stat in ErrandStatuses on err.StatusId equals stat.StatusId
                             join dep in Departments on err.DepartmentId equals dep.DepartmentId
                             into departmentErrand from deptE in departmentErrand.DefaultIfEmpty()
                             join em in Employees on err.EmployeeId equals em.EmployeeId
                             into employeeErrand
                             from empE in employeeErrand.DefaultIfEmpty()
                             orderby err.RefNumber descending
                             select new MyErrand
                             {
                                 DateOfObservation = err.DateOfObservation,
                                 ErrandId = err.ErrandId,
                                 RefNumber = err.RefNumber,
                                 TypeOfCrime = err.TypeOfCrime,
                                 StatusName = stat.StatusName,
                                 DepartmentName = (err.DepartmentId == null ? "ej tillsatt" : deptE.DepartmentName),
                                 EmployeeName = (err.EmployeeId == null ? "ej tillsatt" : empE.EmployeeName)
                             };

            return errendList;
        }

        //Create and Update
        public void SaveErrand(Errand errand)
        {
            if(errand.ErrandId == 0) // this means its a new errand
            {
                Sequence seq = context.sequences.FirstOrDefault();
                errand.RefNumber = "2022-45-" + seq.CurrentValue.ToString(); // sets reference number using the sequence
                errand.StatusId = "S_A"; // hardcoded status
                context.errands.Add(errand); 
                seq.CurrentValue += 1; // incraments the sequence
            }
            else // if it already exists
            {
                Errand dbEntry = context.errands.FirstOrDefault(s => s.ErrandId == errand.ErrandId); // get the errand with the wanted id
                if(dbEntry != null) //if the id given was valid
                {
                    dbEntry.StatusId = errand.StatusId; // update the status 
                    dbEntry.EmployeeId = errand.EmployeeId; // designate the employee
                }
            }
            context.SaveChanges(); // saves the changes that has been tracked so far
        }

        public void UpdateErrandDepartment(string department, int id)
        {
            Errand dbEntry = Errands.FirstOrDefault(s => s.ErrandId == id); // get the entry with the matching id

            if (dbEntry != null) // if it exists
            {
                dbEntry.DepartmentId = department;
                SaveErrand(dbEntry);
            }
            return;
        }

        public void UpdateErrandEmployee(string employee, bool noAction, string investigator, int id)
        {
            if (!noAction)
            {
                Errand dbEntry = Errands.FirstOrDefault(s => s.ErrandId == id);

                if (dbEntry != null)
                {
                    dbEntry.EmployeeId = employee; // specific for changing the emoployee, otherwise its just save
                    SaveErrand(dbEntry);
                }
            }
            else // but if no actio is needed then the status and employeeid needs to reflect that. The info should stull be added
            {
                Errand dbEntry = Errands.FirstOrDefault(s => s.ErrandId == id); 

                if (dbEntry != null)
                {
                    dbEntry.StatusId = "S_B";
                    dbEntry.EmployeeId = null;
                    dbEntry.InvestigatorInfo = investigator;
                    SaveErrand(dbEntry);
                }
            }

            return;
        }

        public void UpdateErrandInvestigation(string statusid, string SampleName, string ImageName, string events, string information, int id)
        {
            Errand dbEntry = Errands.FirstOrDefault(s => s.ErrandId == id);

            if (dbEntry != null)
            {
                if (statusid != "Välj") { dbEntry.StatusId = statusid; } //ignores "empty" feild for status
                dbEntry.InvestigatorAction += " - " + events;
                dbEntry.InvestigatorInfo += " - " + information;

                Sample sample = new Sample();
                sample.ErrandId = dbEntry.ErrandId;
                sample.SampleName = SampleName;
                dbEntry.Samples.Add(sample);

                Picture picture = new Picture();
                picture.ErrandId = dbEntry.ErrandId;
                picture.PictureName = ImageName;
                dbEntry.Pictures.Add(picture);

                SaveErrand(dbEntry);
            }
            return;
        }

        //Delete
        public Errand DeleteErrand(int id)
        {
            Errand dbEntry = context.errands.FirstOrDefault(s => s.ErrandId == id); // get the errand with the wanted id
            if(dbEntry != null) // if its valid
            {
                context.errands.Remove(dbEntry); 
                context.SaveChanges();
            }
            return dbEntry; // retunrs the removed entry incase you want to display it or use it
        }

    }
}
