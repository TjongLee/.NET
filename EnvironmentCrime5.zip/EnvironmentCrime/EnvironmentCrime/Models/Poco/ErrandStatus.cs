﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace EnvironmentCrime.Models
{
    public class ErrandStatus
    {
        [Key]
        [Required(ErrorMessage = "Fyll i status"), Display(Name = "Vilken status?")]
        public String StatusId { get; set; }
        public String StatusName { get; set; }
    }
}
