﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace EnvironmentCrime.Models
{
    public class Employee
    {
        [Required(ErrorMessage = "Fyll i handläggare"), Display(Name = "Vilken handläggare?")]
        public String EmployeeId { get; set; }
        public String EmployeeName { get; set; }
        public String RoleTitle { get; set; }
        public String DepartmentId { get; set; }
        //public bool NoAction { get; set; }
    }
}
